const sqlite3 = require("sqlite3").verbose();
const path = require("path");

// Local do banco
const dbPath = path.join(
    __dirname,
    "bot.sqlite"
);

// Criar conexão
const db = new sqlite3.Database(
    dbPath,
    (err) => {

        if (err) {

            console.error(
                "❌ Erro ao conectar SQLite:",
                err
            );

        } else {

            console.log(
                "🗄️ SQLite conectado"
            );

        }

    }
);

// Ativar foreign keys
db.run(`
    PRAGMA foreign_keys = ON;
`);

// Criar tabelas
db.serialize(() => {

    /*
    =========================
        ECONOMY USERS
    =========================
    */

    db.run(`

        CREATE TABLE IF NOT EXISTS economy_users (

            guild_id TEXT NOT NULL,

            user_id TEXT NOT NULL,

            wallet INTEGER DEFAULT 0,

            bank INTEGER DEFAULT 0,

            xp INTEGER DEFAULT 0,

            level INTEGER DEFAULT 1,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            PRIMARY KEY (
                guild_id,
                user_id
            )

        );
    `);

    db.run(`
ALTER TABLE economy_users
ADD COLUMN daily_at INTEGER DEFAULT NULL;
`, err => {

        if (
            err &&
            !err.message.includes("duplicate column")
        ) {

            console.error(err);

        }

    });

    db.run(`
ALTER TABLE economy_users
ADD COLUMN work_at INTEGER DEFAULT NULL;
`, err => {

        if (
            err &&
            !err.message.includes("duplicate column")
        ) {

            console.error(err);

        }

    });

    /*
    =========================
        ECONOMY TRANSACTIONS
    =========================
    */

    db.run(`

        CREATE TABLE IF NOT EXISTS economy_transactions (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        guild_id TEXT NOT NULL,

        user_id TEXT NOT NULL,

        amount INTEGER NOT NULL,

        type TEXT NOT NULL,

        description TEXT,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP

);

    `);

    /*
    =========================
        WARNINGS
    =========================
    */

    db.run(`

        CREATE TABLE IF NOT EXISTS warnings (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            guild_id TEXT NOT NULL,

            user_id TEXT NOT NULL,

            moderator_id TEXT NOT NULL,

            reason TEXT NOT NULL,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP

        );

    `);

    /*
    =========================
        INVENTÁRIO
    =========================
    */

    db.run(`

        CREATE TABLE IF NOT EXISTS inventories (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            user_id TEXT NOT NULL,

            guild_id TEXT NOT NULL,

            item_id TEXT NOT NULL,

            quantity INTEGER DEFAULT 1,

            UNIQUE(
                user_id,
                guild_id,
                item_id
            )

        );

    `);

    /*
    =========================
        COOLDOWNS
    =========================
    */

    db.run(`

        CREATE TABLE IF NOT EXISTS cooldowns (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            user_id TEXT NOT NULL,

            guild_id TEXT NOT NULL,

            command TEXT NOT NULL,

            expires_at INTEGER NOT NULL,

            UNIQUE(
                user_id,
                guild_id,
                command
            )

        );

    `);

    /*
    =========================
        CONFIGURAÇÕES
    =========================
    */

    db.run(`

        CREATE TABLE IF NOT EXISTS guild_settings (

            guild_id TEXT PRIMARY KEY,

            log_channel TEXT,

            economy_enabled INTEGER DEFAULT 1,

            moderation_enabled INTEGER DEFAULT 1,

            prefix TEXT DEFAULT "!"

        );

    `);

    db.run(`
ALTER TABLE guild_settings
ADD COLUMN log_disabled_categories TEXT DEFAULT '';
`, err => {

        if (
            err &&
            !err.message.includes("duplicate column")
        ) {

            console.error(err);

        }

    });

    /*
    =========================
        TICKETS
    =========================
    */

    db.run(`

        CREATE TABLE IF NOT EXISTS ticket_config (

            guild_id TEXT PRIMARY KEY,

            parent_channel_id TEXT,

            support_role_id TEXT,

            panel_channel_id TEXT,

            next_number INTEGER DEFAULT 1,

            enabled INTEGER DEFAULT 1

        );

    `);

    db.run(`

        CREATE TABLE IF NOT EXISTS tickets (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            guild_id TEXT NOT NULL,

            number INTEGER NOT NULL,

            thread_id TEXT NOT NULL UNIQUE,

            parent_channel_id TEXT NOT NULL,

            user_id TEXT NOT NULL,

            status TEXT NOT NULL DEFAULT 'open',

            claimed_by TEXT,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            closed_at DATETIME,

            closed_by TEXT

        );

    `);

    /*
    =========================
        AUTO-ROLE
    =========================
    */

    db.run(`

        CREATE TABLE IF NOT EXISTS autorole_join (

            guild_id TEXT PRIMARY KEY,

            role_ids TEXT DEFAULT ''

        );

    `);

    db.run(`

        CREATE TABLE IF NOT EXISTS autorole_selfroles (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            guild_id TEXT NOT NULL,

            role_id TEXT NOT NULL,

            label TEXT NOT NULL,

            emoji TEXT,

            UNIQUE(guild_id, role_id)

        );

    `);

    db.run(`

        CREATE TABLE IF NOT EXISTS autorole_levels (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            guild_id TEXT NOT NULL,

            level INTEGER NOT NULL,

            role_id TEXT NOT NULL,

            UNIQUE(guild_id, level)

        );

    `);

    db.run(`
ALTER TABLE guild_settings
ADD COLUMN levelup_enabled INTEGER DEFAULT 1;
`, err => {

        if (
            err &&
            !err.message.includes("duplicate column")
        ) {

            console.error(err);

        }

    });

});

// Helpers

function run(sql, params = []) {

    return new Promise((resolve, reject) => {

        db.run(
            sql,
            params,
            function (err) {

                if (err)
                    reject(err);
                else
                    resolve(this);

            }
        );

    });

}

function get(sql, params = []) {

    return new Promise((resolve, reject) => {

        db.get(
            sql,
            params,
            (err, row) => {

                if (err)
                    reject(err);
                else
                    resolve(row);

            }
        );

    });

}

function all(sql, params = []) {

    return new Promise((resolve, reject) => {

        db.all(
            sql,
            params,
            (err, rows) => {

                if (err)
                    reject(err);
                else
                    resolve(rows);

            }
        );

    });

}

module.exports = {

    db,

    run,

    get,

    all

};